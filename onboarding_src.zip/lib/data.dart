// lib/data.dart

const Map<String, List<String>> governmentToCities = {
  'Cairo': [
    'BADR CITY',
    'ALSALAM',
    'ALMARG',
    'ALMTRYA',
    'AIN SHAMS',
    'HELIOPOLES',
    'ALZETON'
  ],
  'Giza': [
    'ALAGOZA',
    'Alwarrak',
    'KASM AMBABA',
    'OSEEM',
    'Kerdasa',
    'GEZA CANTER'
  ],
  'Alexandria': [
    'ALAMRAYA',
    'ALMNTZH',
    'ALGOMROK',
    'BORG ALARAB',
    'North coast'
  ],
  // Add more governments and cities here
};
